# Universal Trust Adapter (UTA)

> **MCP lets agents use tools. A2A lets agents talk to agents. UTA lets the ecosystem understand and exchange trust.**

UTA normalizes heterogeneous agent identity, capability, authorization and attestation signals into a common trust representation. It translates between ALL trust credential formats via a canonical Universal Trust Schema (UTS).

Like Zapier connects applications, **UTA connects trust standards**.

Built by **Edison Flores** & **Alejandro Flores** at **AliceLabs LLC** (Wyoming, USA).

---

## 📐 3-Layer Architecture

| Layer | What | License | Files |
|-------|------|---------|-------|
| **Plugin Template** | Interface for third-party adapters | MIT | `adapters/types.ts` |
| **UTS Specification** | Universal trust schema (spec + JSON Schema) | CC-BY-NC-ND 4.0 | `spec/UTS-v1.md`, `spec/uts-v1.json`, `spec/UTS-v1.0.json` |
| **Engine + Sentinel** | TrustEngine, adapters, API, Gateway | AL-1.0 (source-available) | `adapters/*.ts`, `adapters/*.mjs`, `api/*.js` |

📖 **Full architecture:** [`docs/ARCHITECTURE.md`](./docs/ARCHITECTURE.md)

---

## 🚀 What UTA does

Translates between ALL agent trust credential formats:

| Format | Type | Owner | Status |
|--------|------|-------|--------|
| ATC v1.0 | Trust credential | AliceLabs | ✅ Stable (frozen) |
| ATC v2.0 | Trust credential (multi-sig) | AliceLabs | ✅ Live |
| EAT-AI | Attestation | IETF | ✅ Beta |
| ZTA | Trust credential | Anthropic | ✅ Beta |
| A2A Agent Card | Capability metadata | Google / AAIF | ✅ Beta |
| MCP Server Card | Server metadata | Anthropic | ✅ Beta |
| W3C VC | Credential model | W3C | ⚠️ Planned |
| OAuth/OIDC | Identity/authorization | IETF | ⚠️ Planned |
| SPIFFE SVID | Workload identity | CNCF | ⚠️ Planned |

**5 implemented → 20 translation pairs.** O(N) adapter complexity — add 1 adapter, get N-1 translations free.

---

## 🔬 Implementation Status (honest)

| Feature | Status | Details |
|---------|--------|---------|
| Schema translation | ✅ Live | All 5 formats |
| Format auto-detection | ✅ Live | Confidence-scored |
| Lossless preservation | ✅ Live | `format.raw` preserves native payload |
| Attestation chaining | ✅ Live | Bridge operations record `original_signature_hash` |
| Policy enforcement | ✅ Live | `min_trust_score` + honeypot detection |
| Ed25519 verification | ✅ Live | Real `crypto.verify()` in ATC adapter |
| RFC 8785 JCS | ✅ Live | Recursive UTF-16 sort + number serialization |
| Revocation (CRL) | ✅ Live | Supabase-backed |
| Proof-of-Possession | ✅ Implemented | Nonce challenge + signature |
| Artifact Binding | ✅ Implemented | Git SHA + npm SHA256 + Docker digest |
| MCP Trust Gateway | ✅ Created | Middleware for `tools/call` interception |
| Mutation tests | ✅ Created | 15 mutation vectors |
| Conformance Suite | ✅ Created | 10 test vectors + MANIFEST |
| Threat Model | ✅ Published | STRIDE + MITRE ATLAS |
| SLSA / Sigstore | ❌ Pending | Needs GitHub Actions CI |
| External pentest | ❌ Pending | Needs third party |

📖 **Full status:** [`IMPLEMENTATION_STATUS.md`](./IMPLEMENTATION_STATUS.md)

---

## 🧪 Try it now

**Live API:** https://universal-trust-adapter.vercel.app/api/trust

```bash
# List supported formats
curl https://universal-trust-adapter.vercel.app/api/trust?action=formats

# Verify any credential (auto-detect)
curl -X POST https://universal-trust-adapter.vercel.app/api/trust?action=verify \
  -H "Content-Type: application/json" \
  -d '{"payload": {...any credential...}}'

# Translate ATC → ZTA (lossless)
curl -X POST https://universal-trust-adapter.vercel.app/api/trust?action=translate \
  -H "Content-Type: application/json" \
  -d '{"to":"zta","payload":{...ATC card...}}'

# Bridge: verify ZTA, issue ATC with attestation chain
curl -X POST https://universal-trust-adapter.vercel.app/api/trust?action=bridge \
  -H "Content-Type: application/json" \
  -d '{"verifyIn":"zta","issueAs":"atc-v2","policy":{"min_trust_score":7},"payload":{...ZTA...}}'
```

---

## 📁 Repository structure

```
universal-trust-adapter/
├── LICENSE                      # AL-1.0 (AliceLabs Source-Available)
├── LICENSE-AL-1.0               # Full license text
├── NOTICE                       # AliceLabs attribution
├── README.md                    # This file
├── EXECUTION_PLAN.md            # 6-month roadmap
├── IMPLEMENTATION_STATUS.md     # Honest crypto status
├── THREAT_MODEL.md              # STRIDE + MITRE ATLAS
├── STRATEGIC_POSITIONING.md      # Competitive analysis
├── CORRECTIONS.md               # 17-point review applied
├── package.json                 # npm: universal-trust-adapter
│
├── adapters/                    # Both TypeScript (source) and JavaScript (runtime)
│   ├── types.ts                 # UTS TypeScript types
│   ├── trust-engine.ts          # TrustEngine (TypeScript source)
│   ├── atc-adapter.ts           # ATC adapter (TypeScript stub)
│   ├── zta-adapter.ts           # ZTA adapter (TypeScript stub)
│   ├── a2a-adapter.ts           # A2A adapter (TypeScript stub)
│   ├── eat-adapter.ts           # EAT adapter (TypeScript stub)
│   ├── mcp-adapter.ts           # MCP adapter (TypeScript stub)
│   ├── vc-adapter.ts            # W3C VC adapter (TypeScript stub)
│   ├── oauth-adapter.ts         # OAuth adapter (TypeScript stub)
│   ├── spiffe-adapter.ts        # SPIFFE adapter (TypeScript stub)
│   ├── index.ts                 # TypeScript barrel export
│   ├── package.json             # @marketnow/trust-core (TS package)
│   ├── schema.mjs               # UTS schema (JavaScript runtime)
│   ├── engine.mjs               # TrustEngine (JavaScript runtime)
│   ├── atc.mjs                  # ATC adapter (JavaScript runtime)
│   ├── eat.mjs                  # EAT adapter (JavaScript runtime)
│   ├── zta.mjs                  # ZTA adapter (JavaScript runtime)
│   ├── a2a.mjs                  # A2A adapter (JavaScript runtime)
│   ├── mcp.mjs                  # MCP adapter (JavaScript runtime)
│   └── index.mjs                # JavaScript barrel export
│
├── api/
│   ├── trust.js                 # Universal Trust API (5 adapters inline)
│   ├── mcp-gateway.js           # MCP Trust Gateway middleware
│   └── trust-api-spec.md        # REST API specification
│
├── tests/
│   └── conformance.mjs          # UTA Conformance Suite
│
├── spec/
│   ├── UTS-v1.md                # UTS specification (markdown)
│   ├── uts-v1.json              # UTS JSON Schema (original)
│   ├── UTS-v1.0.json            # UTS JSON Schema (enhanced with PoP + Artifact Binding)
│   ├── RFC-ATC-v3-Draft-00.md   # ATC v3 draft specification
│   └── test-vectors/            # 10 official conformance test vectors
│       ├── MANIFEST.json
│       ├── valid-atc.json
│       ├── invalid-signature.json
│       ├── expired-atc.json
│       ├── revoked-atc.json
│       ├── valid-zta.json
│       ├── valid-a2a.json
│       ├── valid-mcp.json
│       ├── atc-to-uts.json
│       └── uts-to-zta.json
│
├── fixes/
│   ├── C4-owasp-rename.md       # OWASP MCP Top 10 fix
│   └── owasp-mcp-top-10.md      # Corrected mapping
│
└── docs/
    └── ARCHITECTURE.md           # 3-layer open-core model
```

---

## 🔗 Links

- **Live API**: https://universal-trust-adapter.vercel.app/api/trust
- **Also on MarketNow**: https://marketnow.site/api/trust
- **UTS Schema**: https://universal-trust-adapter.vercel.app/spec/UTS-v1.0.json
- **Test vectors**: https://universal-trust-adapter.vercel.app/spec/test-vectors/MANIFEST.json
- **Threat model**: https://universal-trust-adapter.vercel.app/THREAT_MODEL.md

---

## 📜 License

- **Plugin template** (`adapters/types.ts`): MIT
- **UTS specification** (`spec/`): CC-BY-NC-ND 4.0
- **Engine + Adapters + API**: AL-1.0 (AliceLabs Source-Available License v1.0)

Commercial use requires a separate commercial license. Contact: legal@alicelabs.site

See [LICENSE-AL-1.0](./LICENSE-AL-1.0) for full terms.
