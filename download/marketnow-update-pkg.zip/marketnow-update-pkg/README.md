# MarketNow Site Update Package

This package contains the files needed to add **anti-ban / multi-channel distribution** to marketnow.site.

## What's inside

| File | Destination | Purpose |
|------|-------------|---------|
| `install.sh` | `public/install.sh` | Multi-source installer script |
| `resilience.json` | `public/resilience.json` | Public manifest of all download channels |
| `keys.json` | `public/.well-known/keys.json` | Public Ed25519 signing key |
| `releases.html` | `public/releases.html` | Human-readable releases page |
| `resilience.js` | `api/resilience.js` | Serverless function returning resilience manifest |
| `trust-card.js` | `api/trust-card.js` | Serverless function returning machine-readable trust card |
| `vercel.json` | `vercel.json` | Updated routing with pretty download URLs |

## What this adds to marketnow.site

After deploy, these endpoints all work:
- `https://marketnow.site/install.sh` → multi-source installer
- `https://marketnow.site/resilience.json` → machine-readable manifest
- `https://marketnow.site/trust-card.json` → ATC-format trust card
- `https://marketnow.site/releases/latest` → human-readable releases page
- `https://marketnow.site/download/uts.tgz` → pretty URL for UTS tarball
- `https://marketnow.site/latest/uts.tgz` → always-latest UTS alias

## How to deploy

```bash
cd /home/z/my-project/marketnow/aep-marketplace

# Files are already in place locally. Just deploy:
npx vercel --prod --token YOUR_VERCEL_TOKEN

# OR if you use git for Vercel:
git add public/install.sh public/resilience.json public/.well-known/keys.json \
        public/releases.html api/resilience.js api/trust-card.js vercel.json
git commit -m "feat: anti-ban resilience endpoints + multi-source installer"
git push origin main
```

## Verify after deploy

```bash
# All these should return real content (not HTML)
curl -fsSL https://marketnow.site/install.sh | bash -s -- @marketnow/uts
curl -fsSL https://marketnow.site/resilience.json | jq .packages[0]
curl -fsSL https://marketnow.site/trust-card.json | jq .
curl -fsSL -o /tmp/uts.tgz https://marketnow.site/download/uts.tgz
file /tmp/uts.tgz  # should say "gzip compressed data"
```
